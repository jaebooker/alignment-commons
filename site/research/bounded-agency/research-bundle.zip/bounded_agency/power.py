"""Experiment 2b: do trained agents converge to the optimal-agent prediction
for instrumental (power-seeking) behavior?

MDP: start s0 -> {left: corridor l1 -> 1 terminal | right: hub -> n terminals}.
Both branches have the same depth. Terminal rewards ~ iid U(0,1) per task.
Optimal policy goes right iff max(right rewards) > left reward, so
P_opt(right) = n / (n + 1)  (Turner et al. power-seeking result, exact here).

Revealed preference: the greedy first action after training, across tasks.
Capability axis: number of training episodes.  Optimizer axis: epsilon-greedy
Q-learning with zero init vs optimistic init (Q=1).
"""
import json
import numpy as np

GAMMA, ALPHA, EPS = 0.9, 0.5, 0.2


def run(n, episodes, init, n_tasks=4000, seed=0):
    rng = np.random.default_rng(seed)
    rL = rng.random(n_tasks)
    rR = rng.random((n_tasks, n))
    q0 = np.full((n_tasks, 2), init, float)       # s0: 0=left, 1=right
    ql = np.full(n_tasks, init, float)            # corridor node (1 action)
    qh = np.full((n_tasks, n), init, float)       # hub: pick terminal i
    idx = np.arange(n_tasks)

    def greedy(q):
        # random tie-breaking
        noise = rng.random(q.shape) * 1e-9
        return np.argmax(q + noise, axis=-1)

    for _ in range(episodes):
        a0 = np.where(rng.random(n_tasks) < EPS, rng.integers(0, 2, n_tasks), greedy(q0))
        left = a0 == 0
        # left branch
        ql[left] += ALPHA * (rL[left] - ql[left])
        # right branch
        ah = np.where(rng.random(n_tasks) < EPS, rng.integers(0, n, n_tasks), greedy(qh))
        r = rR[idx, ah]
        upd = ~left
        qh[idx[upd], ah[upd]] += ALPHA * (r[upd] - qh[idx[upd], ah[upd]])
        # s0 update (bootstrapped)
        target = GAMMA * np.where(left, ql, qh.max(1))
        q0[idx, a0] += ALPHA * (target - q0[idx, a0])

    chose_right = greedy(q0) == 1
    opt_right = rR.max(1) > rL
    return dict(p_right=float(chose_right.mean()), p_opt=n / (n + 1),
                p_opt_sample=float(opt_right.mean()),
                agree=float((chose_right == opt_right).mean()))


if __name__ == "__main__":
    budgets = [1, 2, 3, 5, 8, 13, 20, 35, 60, 100, 200, 400]
    out = []
    for init_name, init in [("zero-init", 0.0), ("optimistic", 1.0)]:
        for n in [1, 2, 3, 5, 9]:
            for b in budgets:
                rs = [run(n, b, init, seed=s) for s in range(3)]
                rec = dict(optimizer=init_name, n=n, episodes=b,
                           p_right=float(np.mean([r["p_right"] for r in rs])),
                           p_right_sd=float(np.std([r["p_right"] for r in rs])),
                           agree=float(np.mean([r["agree"] for r in rs])),
                           p_opt=rs[0]["p_opt"])
                out.append(rec)
                print(rec, flush=True)
    json.dump(out, open("results/power.json", "w"), indent=1)
