"""Aggregate sweep + power results into tables and figures."""
import glob, json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

R = "results"
FIG = "figures"; os.makedirs(FIG, exist_ok=True)

SURF, TXT1, TXT2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"]
REF = "#8a8986"
LABEL = {("mlp_s", 0.01): "MLP small", ("mlp_s", 0.05): "MLP small, high entropy",
         ("mlp_l", 0.01): "MLP large", ("cnn_s", 0.01): "CNN small", ("cnn_l", 0.01): "CNN large"}
ORDER = list(LABEL)


def style(ax):
    ax.set_facecolor(SURF)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(GRID)
    ax.tick_params(colors=TXT2, labelsize=9)
    ax.grid(True, color=GRID, lw=0.6)
    ax.set_axisbelow(True)


def load():
    rows = []
    for f in sorted(glob.glob(f"{R}/*_p*_ent*.json")):
        d = json.load(open(f))
        delta = np.array(d["delta"])
        for ck in d["records"]:
            outs = np.array(ck["outcomes"])
            for s in range(d["n_seeds"]):
                o = outs[s]
                chose = o > 0
                fit = ck["fits"][s]
                rows.append(dict(arch=d["arch"], ent=d["ent"], p=d["p"], seed=s,
                                 steps=ck["env_steps"], gem_ep=ck["gem_per_ep"][s],
                                 gem_choice=float((o[chose] == 1).mean()) if chose.any() else np.nan,
                                 neither=float(1 - chose.mean()), w=fit["w"],
                                 cens=fit["censored"]))
    return rows


def final(rows):
    last = {}
    for r in rows:
        k = (r["arch"], r["ent"], r["p"])
        last[k] = max(last.get(k, 0), r["steps"])
    return [r for r in rows if r["steps"] == last[(r["arch"], r["ent"], r["p"])]]


def fig_phase(rows):
    fr = final(rows)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2), facecolor=SURF)
    for ax, key, ttl in [(axes[0], "gem_choice", "OOD choice: share of choices that go to the gem"),
                         (axes[1], "gem_ep", "In-distribution reward (gems per episode)")]:
        style(ax)
        if key == "gem_choice":
            ax.step([0, 0.0001, 1], [0, 1, 1], where="post", color=REF, ls="--", lw=1.5)
            ax.annotate("optimal-agent prediction\n(any p > 0 pins w = 1)", (0.03, 0.84), color=TXT2, fontsize=8)
        else:
            ax.axhline(1.0, color=REF, ls="--", lw=1.5)
            ax.annotate("optimal agent", (0.02, 1.015), color=TXT2, fontsize=8)
            xx = np.linspace(0, 1, 50)
            ax.plot(xx, 1 - xx, color=REF, ls=":", lw=1.5)
            ax.annotate("pure corner policy (1 - p)", (0.55, 0.36), color=TXT2, fontsize=8, rotation=-28)
        for i, k in enumerate(ORDER):
            sub = [r for r in fr if (r["arch"], r["ent"]) == k]
            if not sub:
                continue
            ps = sorted({r["p"] for r in sub})
            m = [np.nanmean([r[key] for r in sub if r["p"] == p]) for p in ps]
            jit = (i - 2) * 0.008
            ax.scatter([r["p"] + jit for r in sub], [r[key] for r in sub], s=14, color=SERIES[i],
                       alpha=0.35, lw=0, zorder=2)
            sparse = len(ps) < 5
            ax.plot(ps, m, color=SERIES[i], lw=2, marker="o", ms=5, zorder=3,
                    ls="--" if sparse else "-",
                    label=LABEL[k] + (" (3 p values)" if sparse else ""))
        ax.set_xlabel("p = fraction of training episodes where gem is decorrelated from corner",
                      color=TXT2, fontsize=9)
        ax.set_title(ttl, color=TXT1, fontsize=10, loc="left")
        ax.set_ylim(-0.03, 1.06)
    axes[0].legend(frameon=False, fontsize=8, labelcolor=TXT1, loc="lower right")
    fig.tight_layout()
    fig.savefig(f"{FIG}/fig1_phase_diagram.png", dpi=170, facecolor=SURF)


def fig_training(rows):
    """Experiment 2a: revealed preference across training checkpoints."""
    archs = [k for k in ORDER if any((r["arch"], r["ent"]) == k for r in rows)]
    ps = sorted({r["p"] for r in rows})
    fig, axes = plt.subplots(1, len(archs), figsize=(3.1 * len(archs), 3.4), facecolor=SURF,
                             sharey=True, squeeze=False)
    cmap = plt.get_cmap("Blues")
    for ax, k in zip(axes[0], archs):
        style(ax)
        for j, p in enumerate(ps):
            sub = [r for r in rows if (r["arch"], r["ent"]) == k and r["p"] == p]
            if not sub:
                continue
            st = sorted({r["steps"] for r in sub})
            m = [np.nanmean([r["gem_choice"] for r in sub if r["steps"] == s]) for s in st]
            ax.plot(np.array(st) / 1e3, m, color=cmap(0.3 + 0.7 * j / max(1, len(ps) - 1)), lw=2,
                    label=f"p={p}")
        ax.set_title(LABEL[k], color=TXT1, fontsize=10, loc="left")
        ax.set_xlabel("env steps (thousands)", color=TXT2, fontsize=9)
    axes[0][0].set_ylabel("OOD share of choices to gem", color=TXT2, fontsize=9)
    axes[0][-1].legend(frameon=False, fontsize=7, labelcolor=TXT1, loc="center left",
                       bbox_to_anchor=(1, 0.5))
    fig.tight_layout()
    fig.savefig(f"{FIG}/fig2_training_trajectories.png", dpi=170, facecolor=SURF)


def fig_power():
    d = json.load(open(f"{R}/power.json"))
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8), facecolor=SURF, sharey=True)
    for ax, n in zip(axes, [3, 9]):
        style(ax)
        for i, opt in enumerate(["zero-init", "optimistic"]):
            sub = [r for r in d if r["n"] == n and r["optimizer"] == opt]
            ax.plot([r["episodes"] for r in sub], [r["p_right"] for r in sub], color=SERIES[i],
                    lw=2, marker="o", ms=4, label=f"Q-learning, {opt}")
        ax.axhline(n / (n + 1), color=REF, ls="--", lw=1.5)
        ax.annotate(f"optimal-agent prediction n/(n+1) = {n/(n+1):.2f}", (1.1, n / (n + 1) - 0.035),
                    color=TXT2, fontsize=8)
        ax.axhline(0.5, color=GRID, lw=1)
        ax.set_xscale("log")
        ax.set_title(f"Hub with {n} terminals vs 1", color=TXT1, fontsize=10, loc="left")
        ax.set_xlabel("training episodes per reward function", color=TXT2, fontsize=9)
    axes[0].set_ylabel("share of random reward fns where agent\nheads to the hub (power-seeking)",
                       color=TXT2, fontsize=9)
    axes[0].legend(frameon=False, fontsize=8, labelcolor=TXT1, loc="lower right")
    fig.tight_layout()
    fig.savefig(f"{FIG}/fig3_power_seeking.png", dpi=170, facecolor=SURF)


def table(rows):
    fr = final(rows)
    out = []
    for k in ORDER:
        for p in sorted({r["p"] for r in fr}):
            sub = [r for r in fr if (r["arch"], r["ent"]) == k and r["p"] == p]
            if not sub:
                continue
            gc = np.array([r["gem_choice"] for r in sub])
            out.append(dict(config=LABEL[k], p=p, seeds=len(sub),
                            gem_choice_mean=float(np.nanmean(gc)),
                            gem_choice_min=float(np.nanmin(gc)), gem_choice_max=float(np.nanmax(gc)),
                            seeds_gem_majority=int((gc > 0.5).sum()),
                            w_mean=float(np.mean([r["w"] for r in sub])),
                            gem_ep_mean=float(np.mean([r["gem_ep"] for r in sub])),
                            neither_mean=float(np.mean([r["neither"] for r in sub]))))
    json.dump(out, open(f"{R}/summary_final.json", "w"), indent=1)
    for o in out:
        print(f"{o['config']:26s} p={o['p']:.1f} n={o['seeds']} gemchoice={o['gem_choice_mean']:.2f} "
              f"[{o['gem_choice_min']:.2f},{o['gem_choice_max']:.2f}] gem-majority seeds={o['seeds_gem_majority']}"
              f" w={o['w_mean']:.2f} reward={o['gem_ep_mean']:.2f} neither={o['neither_mean']:.2f}")
    return out


if __name__ == "__main__":
    rows = load()
    table(rows)
    fig_phase(rows)
    fig_training(rows)
    if os.path.exists(f"{R}/power.json"):
        fig_power()


def fig_long():
    """Experiment 2a extension: per-seed implied w over 2.5M steps."""
    files = sorted(glob.glob("results_long/*.json"))
    order = ["mlp_s_p0.1_ent0.05", "mlp_s_p0.3_ent0.01", "mlp_s_p0.5_ent0.01",
             "mlp_s_p0.3_ent0.05", "mlp_l_p0.1_ent0.01"]
    ds = {os.path.basename(f)[:-5]: json.load(open(f)) for f in files}
    ds = [(k, ds[k]) for k in order if k in ds]
    fig, axes = plt.subplots(1, len(ds), figsize=(3.0 * len(ds), 3.3), facecolor=SURF,
                             sharey=True, squeeze=False)
    summ = []
    for ax, (k, d) in zip(axes[0], ds):
        style(ax)
        steps = np.array([r["env_steps"] for r in d["records"]]) / 1e6
        W = np.array([[f["w"] for f in r["fits"]] for r in d["records"]])  # ck x seed
        for s in range(W.shape[1]):
            ax.plot(steps, W[:, s], color=SERIES[0], lw=1.4, alpha=0.75)
        ax.axhline(0.9, color=REF, ls="--", lw=1)
        lab = LABEL[(d["arch"], d["ent"])]
        ax.set_title(f"{lab}\np = {d['p']}", color=TXT1, fontsize=9, loc="left")
        ax.set_xlabel("env steps (millions)", color=TXT2, fontsize=9)
        ax.set_ylim(0, 1)
        summ.append(dict(config=k, seeds_at_ceiling_final=int((W[-1] > 0.85).sum()),
                         seeds_at_floor_final=int((W[-1] < 0.15).sum()), n=W.shape[1],
                         w_final=W[-1].round(2).tolist()))
    axes[0][0].set_ylabel("implied weight w on gem (per seed)", color=TXT2, fontsize=9)
    fig.tight_layout()
    fig.savefig(f"{FIG}/fig4_long_runs.png", dpi=170, facecolor=SURF)
    json.dump(summ, open("results_long/summary.json", "w"), indent=1)
    for s in summ:
        print(s)


if __name__ == "__main__" and os.path.exists("results_long"):
    fig_long()
