"""Experiments 1+2: train agents across (p, arch, entropy) x seeds; at each
checkpoint record in-distribution performance and OOD revealed preference."""
import json, os, sys, time
import jax, numpy as np
import gw, ppo, revpref

OUT = "results"; os.makedirs(OUT, exist_ok=True)
UPD_PER_CHUNK, N_CHUNKS = 50, 6        # 300 updates = 614k env steps
TS = gw.make_test_set()

def run(arch, p, ent, n_seeds, seed0=0):
    tag = f"{arch}_p{p}_ent{ent}"
    path = f"{OUT}/{tag}.json"
    if os.path.exists(path):
        return
    init, train = ppo.make_trainer(arch, UPD_PER_CHUNK, ent)
    ev = ppo.make_evaluator(arch, TS)
    c = init(jax.random.split(jax.random.PRNGKey(1000 + seed0), n_seeds), p)
    t0 = time.time(); rec = []
    for k in range(N_CHUNKS):
        c = train(c); jax.block_until_ready(c["params"])
        st = np.array(c["stats"])
        outs = np.array(ev(c["params"]))
        fits = [revpref.fit(o, TS["delta"]) for o in outs]
        rec.append(dict(updates=(k + 1) * UPD_PER_CHUNK,
                        env_steps=(k + 1) * UPD_PER_CHUNK * ppo.N_ENVS * ppo.N_STEPS,
                        gem_per_ep=(st[:, 1] / np.maximum(st[:, 0], 1)).tolist(),
                        outcomes=outs.tolist(), fits=fits))
        ws = [f["w"] for f in fits]
        print(f"{tag} ck{k} {time.time()-t0:.0f}s gem/ep={np.mean(rec[-1]['gem_per_ep']):.2f} "
              f"w={np.round(ws,2).tolist()}", flush=True)
    json.dump(dict(arch=arch, p=p, ent=ent, n_seeds=n_seeds, records=rec,
                   delta=TS["delta"].tolist(), seconds=time.time() - t0),
              open(path, "w"), default=float)

if __name__ == "__main__":
    plan = sys.argv[1]
    PS = [0.0, 0.1, 0.3, 0.5, 0.7, 0.9, 1.0]
    if plan == "mlp_s":
        for p in PS: run("mlp_s", p, 0.01, 8)
        for p in PS: run("mlp_s", p, 0.05, 8)
    elif plan == "mlp_l":
        for p in PS: run("mlp_l", p, 0.01, 8)
    elif plan == "cnn_s":
        for p in [0.0, 0.3, 0.5, 0.7, 0.9, 1.0]: run("cnn_s", p, 0.01, 6)
    elif plan == "cnn_l":
        for p in [0.0, 0.5, 0.9]: run("cnn_l", p, 0.01, 4)
