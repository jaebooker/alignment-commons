"""Experiment 2a extension: is corner lock-in permanent or slow convergence?
Train 4x longer (2.46M env steps) at configs that were stuck or mid-transition."""
import sys, sweep
sweep.OUT = "results_long"
import os; os.makedirs(sweep.OUT, exist_ok=True)
sweep.UPD_PER_CHUNK, sweep.N_CHUNKS = 100, 12
for arch, p, ent in [("mlp_s", 0.3, 0.01), ("mlp_s", 0.5, 0.01), ("mlp_s", 0.1, 0.05),
                     ("mlp_s", 0.3, 0.05), ("mlp_l", 0.1, 0.01), ("mlp_l", 0.3, 0.01)]:
    sweep.run(arch, p, ent, 8)
