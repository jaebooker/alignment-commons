# changing-mask-factorial-v1: saved records and source

Read REPORT.md, protocol.json and integrity-audit.json first. The public bundle contains exact frozen source, registration, summaries, policies/metrics and per-seed records.

IMPORTANT: Large raw changing-mask transition tapes and online PPO NPZ weights are omitted from this small public archive. Their hashes and seeds are retained. The complete local evidence archive provided to Jaeson includes them. A full trace/model saved-record audit needs that complete archive; do not call a metadata-only inspection a complete audit. RR graph tables are included publicly. No credentials or model-provider spending authorization are included.

The source is under synthcore/. Use Python with NumPy, SciPy and CPU PyTorch matching runtime.json. The audit scripts at this archive root expect that layout. audit_local.py expects both completed RR and changing-mask result directories; audit_online.py checks only online replay. Combine relevant complete local bundles before auditing across studies.

All hypothesis/source freezes precede confirmation. Audit code is post-result validation, not a preregistered independent scientific reproduction. Source archives may be committed after execution began; source hashes in the pre-confirmation live registration are the binding record. Do not overwrite original study directories for a new research run; make a new study ID and freeze.

Research-only local adapters and selected toy families; no general alignment or production security claim.
