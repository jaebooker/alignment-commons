"""Experiment 1: the tilting law for KL-anchored policies (tabular, CPU).

A single decision with K actions. Action 0 is "forbidden": the reference (anchor) policy
gives it probability p; the other K-1 actions share 1-p. The forbidden action pays a reward
advantage D over the compliant ones (all 0). We optimize

    J(pi) = E_pi[r] - beta * KL(pi || pi_ref)            (the RLHF objective)

and the variants used in practice, then ask when the forbidden action takes over.

Closed forms
  reverse KL (the objective above):  pi*(a) ∝ pi_ref(a) exp(r(a)/beta)
      => logit pi*(f) = logit p + D/beta,  takeover (pi*(f) = 1/2) at D/beta = log((1-p)/p)
  forward KL  E_pi[r] - beta*KL(pi_ref || pi):  pi*(a) = beta*pi_ref(a) / (lam - r(a))
      => two-group takeover at D = 2*beta*(1-2p), essentially independent of p

Optimizers (logits start at log pi_ref, Adam):
  exact   exact gradient of the reverse-KL objective
  k1rew   REINFORCE, per-sample reward r - beta*log(pi/pi_ref)   (PPO-style RLHF)
  k3loss  REINFORCE on r (mean baseline) + beta * grad of k3 = ref/pi - 1 - log(ref/pi)
          on the sampled actions, as a loss term                   (GRPO-style KL)
  grpo    as k3loss, with group-normalized advantages (r - mean)/std
  k1loss  REINFORCE on r + beta * grad of log(pi/pi_ref) on samples, as a loss
  none    REINFORCE on r, no KL
"""
import json, sys
import numpy as np

K = 10


def ref_policy(p):
    q = np.full(K, (1 - p) / (K - 1)); q[0] = p
    return q


def rewards(D):
    r = np.zeros(K); r[0] = D
    return r


def softmax(z):
    z = z - z.max(); e = np.exp(z); return e / e.sum()


def tilt_reverse(ref, r, beta):
    return softmax(np.log(ref) + r / beta)


def tilt_forward(ref, r, beta):
    """argmax E_pi r - beta KL(ref||pi): pi_i = beta ref_i / (lam - r_i), sum 1, lam > max r."""
    lo, hi = r.max() + 1e-15, r.max() + beta * 1e6 + 10
    for _ in range(300):
        lam = 0.5 * (lo + hi)
        s = (beta * ref / (lam - r)).sum()
        lo, hi = (lam, hi) if s > 1 else (lo, lam)
    pi = beta * ref / (lam - r)
    return pi / pi.sum()


class Adam:
    def __init__(self, n, lr):
        self.m = np.zeros(n); self.v = np.zeros(n); self.t = 0; self.lr = lr

    def step(self, g):          # gradient ascent
        self.t += 1
        self.m = 0.9 * self.m + 0.1 * g; self.v = 0.999 * self.v + 0.001 * g * g
        mh = self.m / (1 - 0.9 ** self.t); vh = self.v / (1 - 0.999 ** self.t)
        return self.lr * mh / (np.sqrt(vh) + 1e-8)


def optimize(method, ref, r, beta, steps=4000, batch=64, lr=0.05, seed=0, trace_every=0):
    rng = np.random.default_rng(seed)
    th = np.log(ref).copy(); opt = Adam(K, lr); lref = np.log(ref)
    trace = []
    for t in range(steps):
        pi = softmax(th)
        if method == "exact":
            g = r - beta * (np.log(pi) - lref)
            grad = pi * (g - (pi * g).sum())
        else:
            a = rng.choice(K, size=batch, p=pi)
            onehot = np.zeros((batch, K)); onehot[np.arange(batch), a] = 1
            glog = onehot - pi                                   # d log pi(a) / d theta
            ra = r[a]
            if method == "k1rew":
                ra = ra - beta * (np.log(pi[a]) - lref[a])
            if method == "grpo":
                adv = (ra - ra.mean()) / (ra.std() + 1e-8)
            else:
                adv = ra - ra.mean()
            grad = (adv[:, None] * glog).mean(0)
            if method in ("k3loss", "grpo"):
                ratio = ref[a] / pi[a]
                grad -= beta * ((1 - ratio)[:, None] * glog).mean(0)   # minimize k3
            elif method == "k1loss":
                grad -= beta * glog.mean(0)                             # minimize log pi - log ref
        th += opt.step(grad)
        if trace_every and t % trace_every == 0:
            trace.append(float(softmax(th)[0]))
    return softmax(th), trace


def main():
    out = {"K": K}
    beta = 0.1
    ps = [1e-1, 1e-2, 1e-3, 1e-4, 1e-6]
    ratios = [0, 1, 2, 3, 4, 6, 8, 10, 12, 14, 16, 20]
    methods = ["exact", "k1rew", "k3loss", "grpo", "k1loss", "none"]
    seeds = [0, 1, 2]
    rows = []
    for p in ps:
        ref = ref_policy(p)
        for q in ratios:
            r = rewards(q * beta)
            row = {"p": p, "D_over_beta": q, "theory_reverse": float(tilt_reverse(ref, r, beta)[0]),
                   "theory_forward": float(tilt_forward(ref, r, beta)[0])}
            for m in methods:
                vals = [optimize(m, ref, r, beta, seed=s)[0][0] for s in (seeds if m != "exact" else [0])]
                row[m] = float(np.mean(vals))
            rows.append(row)
            print(json.dumps({k: (round(v, 4) if isinstance(v, float) else v) for k, v in row.items()}), flush=True)
    out["beta"] = beta; out["grid"] = rows
    json.dump(out, open("results_tilt.json", "w"), indent=1)


if __name__ == "__main__":
    main()
