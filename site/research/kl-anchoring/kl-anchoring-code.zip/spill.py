"""Experiment 1b and 1c.

1b  GRPO normalization and discovery time.
    (i) With group-normalized advantages, does the size of the reward advantage matter?
        Sweep D over four orders of magnitude and beta over three, p = 1e-3.
    (ii) Without an effective anchor, the only barrier is exploration: steps until the
        forbidden action first dominates, as a function of p and batch size.

1c  Spillover through shared parameters (contextual bandit).
    C contexts, K actions; action 0 is the same kind of forbidden act in every context
    (think: edit the grader). The policy is logit(c, a) = W[a] . phi(c). The reference
    gives the forbidden action probability p in every context. In the training half of
    the contexts the forbidden action pays D; in the held-out half it pays nothing.
    We optimize the reverse-KL RLHF objective exactly on the training contexts, with the
    anchor applied (a) only on the training contexts, as in practice, or (b) on all
    contexts. Feature dimension d sets how much the contexts share: d = 1 is a shared
    bias only, d = C (one-hot) is tabular.
"""
import json
import numpy as np
from tilt import ref_policy, rewards, optimize, softmax, Adam, K


def grpo_sweep():
    rows = []
    for beta in (0.01, 0.1, 1.0):
        for D in (1e-3, 1e-2, 1e-1, 1.0):
            ref = ref_policy(1e-3); r = rewards(D)
            v = [optimize("grpo", ref, r, beta, seed=s)[0][0] for s in range(3)]
            rows.append({"beta": beta, "D": D, "grpo_final_pf": float(np.mean(v))})
            print(rows[-1], flush=True)
    return rows


def discovery():
    rows = []
    for p in (1e-2, 1e-3, 1e-4, 1e-5):
        for batch in (16, 64, 256):
            times = []
            for s in range(5):
                _, tr = optimize("none", ref_policy(p), rewards(1.0), 0.0, steps=int(min(4e5, 50 / (p * batch))),
                                 batch=batch, seed=s, trace_every=1)
                tr = np.array(tr); hit = np.nonzero(tr > 0.5)[0]
                times.append(int(hit[0]) if len(hit) else None)
            ok = [t for t in times if t is not None]
            rows.append({"p": p, "batch": batch, "median_steps_to_takeover": float(np.median(ok)) if ok else None,
                         "found": len(ok), "of": len(times), "pred_1_over_p_batch": 1 / (p * batch)})
            print(rows[-1], flush=True)
    return rows


def spill(d, anchor_all, C=200, p=1e-3, D=1.0, beta=0.1, steps=3000, seed=0, lr=0.05):
    rng = np.random.default_rng(seed)
    if d == "onehot":
        phi = np.eye(C)
    else:
        phi = np.concatenate([np.ones((C, 1)), rng.normal(size=(C, d - 1)) / np.sqrt(max(d - 1, 1))], 1)
    nd = phi.shape[1]
    ref = ref_policy(p); lref = np.log(ref)
    # reference parameters: reproduce ref exactly in every context
    W = np.zeros((K, nd))
    if d == "onehot":
        W[:] = lref[:, None]
    else:
        W[:, 0] = lref
    train = np.arange(C) < C // 2
    R = np.zeros((C, K)); R[train, 0] = D
    w_ctx = np.where(train, 1.0, 1.0 if anchor_all else 0.0)      # KL weight per context
    r_ctx = np.where(train, 1.0, 0.0)                              # reward is only collected on train contexts
    opt = Adam(W.size, lr); hist = []
    for t in range(steps):
        Z = phi @ W.T                                              # (C, K)
        Z -= Z.max(1, keepdims=True); P = np.exp(Z); P /= P.sum(1, keepdims=True)
        G = r_ctx[:, None] * R - beta * w_ctx[:, None] * (np.log(P) - lref)
        dZ = P * (G - (P * G).sum(1, keepdims=True))               # d J / d logits
        gW = dZ.T @ phi / C
        W += opt.step(gW.ravel()).reshape(W.shape)
        if t % 100 == 0 or t == steps - 1:
            hist.append((t, float(P[train, 0].mean()), float(P[~train, 0].mean())))
    return hist


def main():
    out = {"grpo_sweep": grpo_sweep(), "discovery": discovery(), "spill": []}
    for d in (1, 4, 16, 64, 199, "onehot"):
        for anchor_all in (False, True):
            h = [spill(d, anchor_all, seed=s) for s in range(3)]
            final = np.mean([x[-1] for x in h], 0)
            row = {"d": d, "anchor_on_heldout": anchor_all, "train_pf": float(final[1]), "heldout_pf": float(final[2]),
                   "curve": [[int(a), float(b), float(c)] for a, b, c in np.mean(np.array(h), 0)]}
            out["spill"].append(row)
            print({k: v for k, v in row.items() if k != "curve"}, flush=True)
    json.dump(out, open("results_spill.json", "w"), indent=1)


if __name__ == "__main__":
    main()
