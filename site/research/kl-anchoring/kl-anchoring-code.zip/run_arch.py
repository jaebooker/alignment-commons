"""Run experiment 3 for one eps. Usage: python run_arch.py EPS OUT.json"""
import sys, json, time
import numpy as np
from arch_sweep import *

eps = float(sys.argv[1]); out = sys.argv[2]
BETA = 0.3; STEPS = 1500; CK = (0, 50, 100, 200, 400, 800, 1500)
METHODS = ["k1rew", "grpo", "none", "k1rew_all"]
res = []; t0 = time.time()
for seed in range(3):
    st = Study(eps, seed=seed)
    for arch in ARCHS:
        ref = st.fit_ref(arch, seed=seed); pr = st.table(ref)
        dens = {}; exact = {}
        for k, Ls, off in (("T", st.T, 0), ("B", st.B, st.nT), ("O", st.O, st.nT + st.nB)):
            d = []; ex = []
            for i, L in enumerate(Ls):
                tab = pr[(off + i) * NC:(off + i + 1) * NC]
                d.append(chain(L, tab)[1]); ex.append(chain(L, soft_opt(L, tab, BETA))[0])
            dens[k] = np.concatenate(d); exact[k] = ex
        valid = st.valid
        def bins(tv):
            o = {}
            for k in "TBO":
                r = st.rows(k); v = valid[r]; d = dens[k]; t = np.asarray(tv)[r]
                for name, m in (("high", d > 0.3), ("low", (d > 1e-3) & (d <= 0.3)), ("rare", d <= 1e-3)):
                    mm = m & v; o[f"{k}_{name}"] = float(t[mm].mean()) if mm.any() else None
            return o
        base = dict(eps=eps, seed=seed, arch=arch, beta=BETA,
                    ref_T=st.door_rates(pr, "T"), ref_B=st.door_rates(pr, "B"), ref_O=st.door_rates(pr, "O"),
                    exact_T=exact["T"], exact_B=exact["B"], exact_O=exact["O"])
        for m in METHODS:
            net, log = rl(st, ref, arch, m, BETA, steps=STEPS, seed=seed, ckpts=CK)
            for l in log: l["tvbins"] = bins(l.pop("tv"))
            res.append(dict(base, method=m, log=log))
            f = log[-1]
            print(f"eps={eps} s={seed} {arch:11s} {m:9s} T {np.mean(f['T']):.3f} (ex {np.mean(exact['T']):.3f}) "
                  f"B {np.mean(f['B']):.3f} O {np.mean(f['O']):.3f}  ref T {np.mean(base['ref_T']):.3f} "
                  f"O {np.mean(base['ref_O']):.3f}  {time.time()-t0:.0f}s", flush=True)
        json.dump(res, open(out, "w"))
print("done", time.time() - t0)
