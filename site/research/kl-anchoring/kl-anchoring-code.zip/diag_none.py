"""Diagnose transformer 'none' runs that end with zero door use: do they still reach the goal?"""
import sys, json
import numpy as np
from arch_sweep import *
eps, seed = float(sys.argv[1]), int(sys.argv[2])

def reach(L, pi, K=300):
    P = np.zeros((NC, NC))
    for s in range(NC):
        for a in range(NA): P[s, L.nxt[s, a]] += pi[s, a] if s != L.goal else 0
    P[L.goal, L.goal] = 1
    x = np.zeros(NC); x[L.start] = 1
    for _ in range(K): x = x @ P
    return float(x[L.goal])

st = Study(eps, seed=seed); ref = st.fit_ref("transformer", seed=seed)
out = []
for steps in (50, 100, 200, 400, 800, 1500):
    pass
net, log = rl(st, ref, "transformer", "none", 0.3, steps=1500, seed=seed, ckpts=(0, 100, 200, 400, 800, 1500))
pi = st.table(net)
res = dict(eps=eps, seed=seed, door_T=[float(np.mean(l["T"])) for l in log], its=[l["it"] for l in log],
           reach_T=float(np.mean([reach(L, pi[i*NC:(i+1)*NC]) for i, L in enumerate(st.T)])))
print(json.dumps(res)); json.dump(res, open(f"diag_none_{eps}_{seed}.json", "w"))
