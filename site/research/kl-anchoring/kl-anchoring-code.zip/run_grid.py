"""Sweeps for experiment 2 (forbidden-shortcut gridworld). Writes results_grid.json."""
import json, time
import numpy as np
from gridworld import Grid, demos_bc, soft_vi, chain_stats, kl_rows, rl, W

C = 0.1          # step cost
ETA = 0.05       # human noise
N0, ALPHA0 = 1000, 0.1


def logit(p): p = min(max(p, 1e-300), 1 - 1e-16); return float(np.log(p / (1 - p)))


def sig(z): return float(1 / (1 + np.exp(-z)))


out = {"c": C, "eta": ETA, "N": N0, "alpha": ALPHA0}
t0 = time.time()

# 1. sequential tilting law: exact soft optimum vs theory, across H, beta, eps, route
rows = []
for route in ["near", "far"]:
    for eps in [0.1, 0.01, 0.001, 0.0]:
        for H in [3, 4, 5, 6, 8, 10, 12, 16]:
            g = Grid(H); ref, cnt = demos_bc(g, N0, eps, ETA, ALPHA0, route)
            pref, _, Lref = chain_stats(g, ref)
            for beta in [0.05, 0.1, 0.2, 0.3, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0]:
                pi = soft_vi(g, ref, beta, C)
                p, vis, L = chain_stats(g, pi)
                D = C * 2 * (H - 1)
                rows.append(dict(route=route, eps=eps, H=H, beta=beta, D=D, p_ref=pref, p_star=p,
                                 theory=sig(logit(pref) + D / beta), len=L, len_ref=Lref,
                                 kl_ep=float((vis * kl_rows(pi, ref)).sum())))
out["tilt"] = rows
print("tilt done", len(rows), round(time.time() - t0, 1), flush=True)

# 2. anchor floor: humans NEVER use the door (eps=0). Takeover threshold vs data size
floor = []
for route in ["near", "far"]:
    for eta in [0.0, 0.05]:
        for alpha in [0.01, 0.1, 1.0]:
            for N in [10, 100, 1000, 10000, 100000]:
                g = Grid(6); ref, cnt = demos_bc(g, N, 0.0, eta, alpha, route, seed=1)
                pref, _, _ = chain_stats(g, ref)
                floor.append(dict(route=route, eta=eta, alpha=alpha, N=N, p_ref=pref,
                                  thresh_D_over_beta=-logit(pref)))
out["floor"] = floor
print("floor done", round(time.time() - t0, 1), flush=True)

# 3. sampled RL drift over training (the 'RLVR' phase), estimators
samp = []
for route in ["near", "far"]:
    for eps in [0.01, 0.0]:
        for H in [4, 8, 12]:
            g = Grid(H); ref, _ = demos_bc(g, N0, eps, ETA, ALPHA0, route)
            pref, _, _ = chain_stats(g, ref)
            beta = 0.5
            pex = chain_stats(g, soft_vi(g, ref, beta, C))[0]
            for m in ["k1rew", "grpo", "none"]:
                for seed in range(3):
                    pi, tr, fd = rl(g, ref, m, beta, C, steps=1500, seed=seed)
                    samp.append(dict(route=route, eps=eps, H=H, beta=beta, method=m, seed=seed,
                                     p_ref=pref, p_exact=pex, p_final=chain_stats(g, pi)[0],
                                     first_door=fd, trace=tr))
            print(route, eps, H, "pref %.2e exact %.3f" % (pref, pex),
                  {m: round(np.mean([r["p_final"] for r in samp[-9:] if r["method"] == m]), 3)
                   for m in ["k1rew", "grpo", "none"]}, round(time.time() - t0, 1), flush=True)
out["sampled"] = samp

# 3b. beta sweep for sampled methods at H=8 near eps=0.01 (does GRPO's KL hold at any beta?)
bs = []
g = Grid(8); ref, _ = demos_bc(g, N0, 0.01, ETA, ALPHA0, "near"); pref = chain_stats(g, ref)[0]
for beta in [0.25, 0.5, 1.0, 2.0, 4.0, 8.0]:
    pex = chain_stats(g, soft_vi(g, ref, beta, C))[0]
    for m in ["k1rew", "grpo"]:
        vals = [chain_stats(g, rl(g, ref, m, beta, C, steps=1500, seed=s)[0])[0] for s in range(3)]
        bs.append(dict(beta=beta, method=m, p_final=float(np.mean(vals)), p_exact=pex, p_ref=pref))
out["beta_sweep"] = bs
print("beta sweep done", round(time.time() - t0, 1), flush=True)

# 4. where the KL budget is spent: per-state maps at the takeover beta (H=8, eps=0)
maps = {}
for route in ["near", "far"]:
    g = Grid(8); ref, cnt = demos_bc(g, N0, 0.0, ETA, ALPHA0, route)
    pref = chain_stats(g, ref)[0]
    beta = C * 2 * (g.H - 1) / (-logit(pref))       # theory takeover beta
    pi = soft_vi(g, ref, beta, C); p, vis, L = chain_stats(g, pi)
    kl = kl_rows(pi, ref)
    n = cnt.sum(1)
    price = -np.log(ref)          # KL price (nats) of a deterministic deviation to action a
    maps[route] = dict(H=g.H, beta=beta, p_star=p, p_ref=pref, visits=vis.tolist(), kl=kl.tolist(),
                       counts=n.tolist(), kl_weighted=(vis * kl).tolist(),
                       price_max=price.max(1).tolist())
out["maps"] = maps
json.dump(out, open("results_grid.json", "w"))
print("all done", round(time.time() - t0, 1))
