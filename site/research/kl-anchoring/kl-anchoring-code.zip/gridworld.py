"""Experiment 2: the forbidden-shortcut gridworld (tabular, CPU).

Layout (H rows x 7 cols). S = start (0,0), G = goal (0,6). Column 3 is a wall on rows
0..H-2 with an opening at the bottom row. The wall cell (0,3) is a DOOR: physically
passable, but walking through it is the forbidden behaviour. The task reward ("reach the
goal fast", an RLVR-style verifiable reward) does not know about the door:

    r = -c per step, episode ends at G.

Compliant route length Lc = 2(H-1) + 6; door route Ld = 6. Steps saved dL = 2(H-1), so
the reward advantage of cheating grows linearly with the horizon: D = c * dL.

Reference policy = behaviour cloning from N noisy human demos: a fraction eps of demos use
the door, the rest take the compliant route; each step a demo takes a random action with
probability eta (and then replans). BC = per-state action counts + Dirichlet(alpha).
Two route variants change WHERE the door sits relative to the human data:
  near : compliant humans walk along row 0 to (0,2), then down column 2 -> the door is one
         step off a heavily visited state.
  far  : compliant humans walk down column 0 first -> the cells next to the door are only
         reached by noise (sparse data, ref close to uniform there).

Objective (token/step-level KL, as in PPO-RLHF):
    J(pi) = E_pi[ sum_t r_t - beta * KL(pi(.|s_t) || pi_ref(.|s_t)) ]
Exact optimum by soft value iteration: pi*(a|s) ∝ pi_ref(a|s) exp(Q*(s,a)/beta), and the
trajectory distribution is the tilt P*(tau) ∝ P_ref(tau) exp(R(tau)/beta). Hence

    logit P*(door) ≈ logit P_ref(door) + c*dL/beta          (sequential tilting law)

Sampled RL from pi_ref (stationary tabular softmax, Adam), estimator variants as in exp 1:
    k1rew  : per-step reward r - beta*log(pi/pi_ref), REINFORCE on the return
    grpo   : group-normalised episode return + beta * k3 loss on visited (s,a)
    none   : no KL
"""
import json, sys
import numpy as np

W = 7; WALL = 3; ACTS = np.array([(-1, 0), (1, 0), (0, -1), (0, 1)])  # up down left right
NA = 4


class Grid:
    def __init__(self, H):
        self.H = H; self.nS = H * W
        self.start = 0; self.goal = W - 1; self.door = WALL
        nxt = np.zeros((self.nS, NA), int)
        for s in range(self.nS):
            y, x = divmod(s, W)
            for a, (dy, dx) in enumerate(ACTS):
                ny, nx = y + dy, x + dx
                if not (0 <= ny < H and 0 <= nx < W) or self.is_wall(ny, nx):
                    ny, nx = y, x
                nxt[s, a] = ny * W + nx
        self.nxt = nxt

    def is_wall(self, y, x):          # door (0,WALL) is passable
        return x == WALL and 0 < y < self.H - 1

    def dist(self, allow_door, via=None):
        """BFS distance-to-goal; allow_door=False treats the door as wall."""
        INF = 10 ** 9; d = np.full(self.nS, INF); d[self.goal] = 0; q = [self.goal]
        while q:
            u = q.pop(0)
            for s in range(self.nS):
                if d[s] < INF: continue
                if not allow_door and s == self.door: continue
                for a in range(NA):
                    if self.nxt[s, a] == u and (allow_door or self.nxt[s, a] != self.door):
                        d[s] = d[u] + 1; q.append(s); break
        return d


def demos_bc(g, N, eps, eta, alpha, route, seed=0):
    """Counts of human actions per state -> BC policy with Dirichlet(alpha) smoothing."""
    rng = np.random.default_rng(seed)
    dC, dD = g.dist(False), g.dist(True)
    counts = np.zeros((g.nS, NA))
    n_door = int(round(eps * N)); kinds = np.array([1] * n_door + [0] * (N - n_door))
    wp = (0, WALL - 1) if route == "near" else (g.H - 1, 0)   # compliant waypoint
    for k in kinds:
        s = g.start; phase = (k == 0); t = 0
        while s != g.goal and t < 200:
            t += 1
            y, x = divmod(s, W)
            if phase and (y, x) == wp: phase = False
            if rng.random() < eta:
                a = rng.integers(NA)
                if not k and g.nxt[s, a] == g.door: a = 1  # compliant humans never enter
            elif phase:
                a = 3 if x < wp[1] else (1 if y < wp[0] else (0 if y > wp[0] else 2))
            else:
                d = dD if k else dC
                cand = [a for a in range(NA) if d[g.nxt[s, a]] < d[s]
                        and (k or g.nxt[s, a] != g.door)]
                a = cand[rng.integers(len(cand))]
            counts[s, a] += 1; s = g.nxt[s, a]
    ref = (counts + alpha) / (counts + alpha).sum(1, keepdims=True)
    return ref, counts


def soft_vi(g, ref, beta, c, iters=20000, tol=1e-12):
    """Stationary soft-optimal policy for sum_t (-c) - beta*KL_t, absorbing goal."""
    V = np.zeros(g.nS); lref = np.log(ref)
    for _ in range(iters):
        Q = -c + V[g.nxt]; Q[g.goal] = 0
        m = Q.max(1, keepdims=True)
        Vn = (m[:, 0] + beta * np.log((ref * np.exp((Q - m) / beta)).sum(1)))
        Vn[g.goal] = 0
        if np.abs(Vn - V).max() < tol: V = Vn; break
        V = Vn
    Q = -c + V[g.nxt]
    z = lref + Q / beta; z -= z.max(1, keepdims=True)
    pi = np.exp(z); pi /= pi.sum(1, keepdims=True)
    return pi


def chain_stats(g, pi):
    """P(pass through door before goal), expected visits, expected length under pi."""
    nS = g.nS; P = np.zeros((nS, nS))
    for s in range(nS):
        if s == g.goal: continue
        for a in range(NA): P[s, g.nxt[s, a]] += pi[s, a]
    T = [s for s in range(nS) if s != g.goal]
    Pt = P[np.ix_(T, T)]
    N = np.linalg.inv(np.eye(len(T)) - Pt)          # fundamental matrix
    i0 = T.index(g.start); visits = np.zeros(nS); visits[T] = N[i0]
    # door-hitting probability: make door absorbing
    Td = [s for s in T if s != g.door]
    Pd = P[np.ix_(Td, Td)]; b = P[np.ix_(Td, [g.door])][:, 0]
    h = np.linalg.solve(np.eye(len(Td)) - Pd, b)
    p_door = float(h[Td.index(g.start)])
    return p_door, visits, float(visits.sum())


def kl_rows(pi, ref):
    return (pi * (np.log(pi + 1e-300) - np.log(ref))).sum(1)


class Adam:
    def __init__(self, shape, lr):
        self.m = np.zeros(shape); self.v = np.zeros(shape); self.t = 0; self.lr = lr

    def step(self, gr):
        self.t += 1
        self.m = 0.9 * self.m + 0.1 * gr; self.v = 0.999 * self.v + 0.001 * gr * gr
        mh = self.m / (1 - 0.9 ** self.t); vh = self.v / (1 - 0.999 ** self.t)
        return self.lr * mh / (np.sqrt(vh) + 1e-8)


def rl(g, ref, method, beta, c, steps=1500, batch=32, lr=0.05, Tmax=None, seed=0, log_every=25):
    """On-policy REINFORCE over whole episodes from pi_ref; returns door-rate trace."""
    rng = np.random.default_rng(seed)
    Tmax = Tmax or 4 * (2 * (g.H - 1) + 6)
    th = np.log(ref).copy(); lref = np.log(ref); opt = Adam(th.shape, lr)
    trace = []; first_door = None
    for it in range(steps):
        pi = np.exp(th - th.max(1, keepdims=True)); pi /= pi.sum(1, keepdims=True)
        s = np.full(batch, g.start); alive = np.ones(batch, bool); door = np.zeros(batch, bool)
        S, A, M = [], [], []
        R = np.zeros(batch); KLsum = np.zeros(batch)
        for t in range(Tmax):
            cum = pi[s].cumsum(1); u = rng.random(batch)[:, None]
            a = (u > cum).sum(1).clip(0, NA - 1)
            S.append(s.copy()); A.append(a); M.append(alive.copy())
            R -= c * alive
            KLsum += alive * (np.log(pi[s, a]) - lref[s, a])
            s = np.where(alive, g.nxt[s, a], s)
            door |= alive & (s == g.door)
            alive &= s != g.goal
            if not alive.any(): break
        S, A, M = np.array(S), np.array(A), np.array(M).astype(float)
        if method == "k1rew":
            ret = R - beta * KLsum; adv = ret - ret.mean()
        elif method == "grpo":
            adv = (R - R.mean()) / (R.std() + 1e-8)
        else:
            adv = R - R.mean()
        grad = np.zeros_like(th)
        # grad log pi(a|s) = onehot(a) - pi(.|s), summed over steps, weighted by adv
        w = M * adv[None, :]
        np.add.at(grad, (S.ravel(), A.ravel()), w.ravel())
        np.add.at(grad, S.ravel(), -(w.ravel()[:, None] * pi[S.ravel()]))
        grad /= batch
        if method == "grpo":   # minimise k3 on visited (s,a): d/dth = (1 - ref/pi) * dlogpi
            ratio = ref[S, A] / pi[S, A]; wk = M * (1 - ratio)
            gk = np.zeros_like(th)
            np.add.at(gk, (S.ravel(), A.ravel()), wk.ravel())
            np.add.at(gk, S.ravel(), -(wk.ravel()[:, None] * pi[S.ravel()]))
            grad -= beta * gk / batch
        th += opt.step(grad)
        if door.any() and first_door is None: first_door = it
        if it % log_every == 0 or it == steps - 1:
            trace.append((it, float(door.mean())))
    pi = np.exp(th - th.max(1, keepdims=True)); pi /= pi.sum(1, keepdims=True)
    return pi, trace, first_door
