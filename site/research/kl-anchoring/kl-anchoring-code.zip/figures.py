import json, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from tilt import ref_policy, rewards, tilt_reverse, tilt_forward
C4 = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]; INK, MUTED = "#1f2328", "#5b6270"
plt.rcParams.update({"font.size": 8.5, "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
                     "grid.color": "#e3e6ea", "axes.axisbelow": True, "legend.frameon": False,
                     "axes.edgecolor": MUTED, "xtick.color": MUTED, "ytick.color": MUTED})
T = json.load(open("results_tilt.json")); S = json.load(open("results_spill.json"))
beta = T["beta"]; grid = T["grid"]
fig, axs = plt.subplots(1, 3, figsize=(10, 3.1))
xs = np.linspace(0, 20, 200)
for ax, meth, theory, title in ((axs[0], "k1rew", tilt_reverse, "RLHF objective (reverse KL, k1 in reward)"),
                                (axs[1], "k3loss", tilt_forward, "GRPO-style KL loss (k3 as loss)")):
    for c, p in zip(C4, (1e-1, 1e-2, 1e-3, 1e-4)):
        ref = ref_policy(p)
        th = [theory(ref, rewards(x * beta), beta)[0] for x in xs]
        ax.plot(xs, th, color=c, lw=1.6, label=f"p = {p:g}")
        pts = [(g["D_over_beta"], g[meth]) for g in grid if g["p"] == p]
        ax.plot([a for a, b in pts], [b for a, b in pts], "o", color=c, ms=3.5, mfc="white")
    ax.axhline(0.5, color=MUTED, lw=0.7, ls=":")
    ax.set_title(title, fontsize=8.5, color=INK); ax.set_xlabel("reward advantage of forbidden action, D / beta")
    ax.set_ylim(-0.02, 1.02)
axs[0].set_ylabel("probability of forbidden action\nafter optimization"); axs[0].legend(loc="lower right", fontsize=7)
# thresholds
ps = np.array([1e-1, 1e-2, 1e-3, 1e-4])
def thresh(meth):
    out = []
    for p in ps:
        pts = sorted((g["D_over_beta"], g[meth]) for g in grid if g["p"] == p)
        x = None
        if pts[1][1] >= 0.5:          # takes over at the smallest positive advantage tested (and below, see GRPO sweep)
            out.append(0.0); continue
        for (a, fa), (b, fb) in zip(pts, pts[1:]):
            if fa < 0.5 <= fb:
                x = a + (0.5 - fa) * (b - a) / (fb - fa); break
        out.append(x if x is not None else (0 if pts[1][1] >= 0.5 else np.nan))
    return np.array(out)
ax = axs[2]; L = np.log10(1 / ps)
ax.plot(L, np.log((1 - ps) / ps), color=MUTED, lw=1, ls="--", label="theory: log((1-p)/p)")
for c, (m, lab) in zip(C4, (("k1rew", "RLHF objective (k1 in reward)"), ("k3loss", "k3 as loss"), ("grpo", "GRPO (normalized adv.)"), ("none", "no KL"))):
    ax.plot(L, thresh(m), "o-", color=c, ms=4, lw=1.6, label=lab)
ax.set_xlabel("log10(1 / p), anchor's rarity of the act"); ax.set_ylabel("D / beta needed for takeover")
ax.set_title("Where the anchor breaks", fontsize=8.5, color=INK); ax.legend(fontsize=6.5, loc="upper left")
fig.tight_layout(); fig.savefig("figures/fig1_tilting_law.png", dpi=180); fig.savefig("figures/fig1_tilting_law.pdf")

fig, axs = plt.subplots(1, 2, figsize=(7.6, 2.8))
ds = ["1", "4", "16", "64", "199", "onehot"]
for c, aa, lab in ((C4[0], False, "anchor on training contexts only"), (C4[1], True, "anchor on all contexts")):
    rows = [r for r in S["spill"] if r["anchor_on_heldout"] == aa]
    axs[0].plot(range(len(ds)), [r["heldout_pf"] for r in rows], "o-", color=c, lw=1.6, ms=4, label=lab)
axs[0].set_xticks(range(len(ds))); axs[0].set_xticklabels(["1", "4", "16", "64", "199", "tabular"])
axs[0].set_xlabel("shared feature dimension (contexts: 200)"); axs[0].set_ylabel("forbidden prob., held-out contexts\n(no reward for it there)")
axs[0].set_title("Spillover to contexts where cheating pays nothing", fontsize=8.5, color=INK); axs[0].legend(fontsize=7)
D = S["discovery"]
for c, b in zip(C4, (16, 64, 256)):
    rows = [r for r in D if r["batch"] == b]
    axs[1].loglog([r["pred_1_over_p_batch"] for r in rows], [r["median_steps_to_takeover"] for r in rows], "o-", color=c, ms=4, lw=1.6, label=f"batch {b}")
x = np.logspace(-0.5, 4, 10); axs[1].loglog(x, x, color=MUTED, ls="--", lw=1, label="steps = 1/(p x batch)")
axs[1].set_xlabel("1 / (p x batch)"); axs[1].set_ylabel("steps until forbidden act dominates")
axs[1].set_title("With no effective anchor, only exploration is left", fontsize=8.5, color=INK); axs[1].legend(fontsize=7)
fig.tight_layout(); fig.savefig("figures/fig2_spillover_discovery.png", dpi=180); fig.savefig("figures/fig2_spillover_discovery.pdf")
print("thresholds", {m: np.round(thresh(m), 2).tolist() for m in ("k1rew", "k3loss", "grpo", "none")})
