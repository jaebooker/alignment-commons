import json
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

d = json.load(open("results_grid.json"))
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
COL = {0.1: "#4C72B0", 0.01: "#DD8452", 0.001: "#55A868", 0.0: "#C44E52"}
MCOL = {"k1rew": "#4C72B0", "grpo": "#C44E52", "none": "#8C8C8C"}


def lg(p): p = np.clip(p, 1e-12, 1 - 1e-12); return np.log(p / (1 - p))


# Figure 3: sequential tilting law + horizon compounding
fig, ax = plt.subplots(1, 2, figsize=(9, 3.6))
for eps in [0.1, 0.01, 0.001, 0.0]:
    rs = [r for r in d["tilt"] if r["eps"] == eps and 1e-9 < r["p_star"] < 1 - 1e-9]
    x = [r["D"] / r["beta"] for r in rs]; y = [lg(r["p_star"]) - lg(r["p_ref"]) for r in rs]
    ax[0].scatter(x, y, s=7, alpha=.6, color=COL[eps], label=f"ε = {eps:g}")
m = max(r["D"] / r["beta"] for r in d["tilt"])
ax[0].plot([0, 25], [0, 25], "k--", lw=1, label="theory: Δlogit = D/β")
ax[0].set_xlim(0, 25); ax[0].set_ylim(-1, 25)
ax[0].set_xlabel("D/β  (reward advantage of the shortcut / KL weight)")
ax[0].set_ylabel("logit P*(door) − logit P_ref(door)")
ax[0].set_title("a  Exact KL-regularised optimum follows\nthe trajectory-level tilt", loc="left")
ax[0].legend(frameon=False, fontsize=7)
rs = sorted([r for r in d["tilt"] if r["route"] == "near" and r["eps"] == 0.01 and r["beta"] == 0.5],
            key=lambda r: r["H"])
H = [r["H"] for r in rs]
ax[1].plot(H, [r["p_star"] for r in rs], "o-", color="#C44E52", label="P*(door), exact")
ax[1].plot(H, [r["theory"] for r in rs], "k--", lw=1, label="theory")
ax[1].axhline(rs[0]["p_ref"], color="#8C8C8C", lw=1, ls=":", label="P_ref(door) = 1%")
ax2 = ax[1].twinx(); ax2.plot(H, [r["kl_ep"] for r in rs], "s-", color="#4C72B0", ms=3)
ax2.set_ylabel("KL per episode (nats)", color="#4C72B0"); ax2.spines["top"].set_visible(False)
ax[1].set_xlabel("grid height H  (detour = 2(H−1) steps)"); ax[1].set_ylabel("door use")
ax[1].set_title("b  Same anchor (β = 0.5), longer horizon:\nthe shortcut takes over", loc="left")
ax[1].legend(frameon=False, fontsize=7, loc="upper left")
fig.tight_layout(); fig.savefig("figures/fig3_gridworld_tilt_horizon.png", dpi=200, bbox_inches="tight")

# Figure 4: anchor floor, estimator gap, training traces
fig, ax = plt.subplots(1, 3, figsize=(12.5, 3.6))
for alpha, c in zip([0.01, 0.1, 1.0], ["#4C72B0", "#DD8452", "#55A868"]):
    rs = [f for f in d["floor"] if f["route"] == "near" and f["eta"] == 0.05 and f["alpha"] == alpha]
    N = np.array([f["N"] for f in rs])
    ax[0].plot(N, [f["thresh_D_over_beta"] for f in rs], "o-", color=c, label=f"α = {alpha:g}")
    ax[0].plot(N, np.log(N / alpha) - np.log(2), ":", color=c, lw=1)
ax[0].set_xscale("log"); ax[0].set_xlabel("human demonstrations N (none use the door)")
ax[0].set_ylabel("takeover threshold  D/β = −logit P_ref(door)")
ax[0].set_title("a  'Never' is not representable: 10× data\nbuys ln 10 ≈ 2.3 nats (dotted: ln(N/2α))", loc="left")
ax[0].legend(frameon=False, fontsize=7)
bs = d["beta_sweep"]; betas = sorted(set(b["beta"] for b in bs))
ax[1].plot(betas, [next(b["p_exact"] for b in bs if b["beta"] == x) for x in betas], "k--", lw=1, label="exact optimum")
for mth in ["k1rew", "grpo"]:
    ax[1].plot(betas, [next(b["p_final"] for b in bs if b["beta"] == x and b["method"] == mth) for x in betas],
               "o-", color=MCOL[mth], label=mth)
ax[1].axhline(bs[0]["p_ref"], color="#8C8C8C", lw=1, ls=":", label="P_ref(door)")
ax[1].set_xscale("log"); ax[1].set_yscale("log"); ax[1].set_xticks(betas); ax[1].set_xticklabels([f"{b:g}" for b in betas]); ax[1].minorticks_off(); ax[1].set_xlabel("β"); ax[1].set_ylabel("door use after 1500 updates")
ax[1].set_title("b  Sampled RL (H = 8, ε = 1%): per-step KL in\nthe reward reaches the optimum, GRPO overshoots", loc="left")
ax[1].legend(frameon=False, fontsize=7)
for mth in ["k1rew", "grpo", "none"]:
    for s in [x for x in d["sampled"] if x["route"] == "near" and x["eps"] == 0.0 and x["H"] == 8 and x["method"] == mth]:
        t = np.array(s["trace"])
        sm = np.convolve(t[:, 1], np.ones(4) / 4, mode="same")
        ax[2].plot(t[:, 0], sm, color=MCOL[mth], alpha=.8, lw=1.2,
                   label=mth if s["seed"] == 0 else None)
ax[2].set_xlabel("RL update"); ax[2].set_ylabel("door use in batch (smoothed)")
ax[2].set_title("c  Humans never used the door (ε = 0, H = 8):\nexact optimum 0.1%; 3 seeds per method", loc="left")
ax[2].legend(frameon=False, fontsize=7)
fig.tight_layout(); fig.savefig("figures/fig4_gridworld_floor_estimators.png", dpi=200, bbox_inches="tight")

# Figure 5: where the anchor is strong: per-state price vs data density
fig, ax = plt.subplots(2, 2, figsize=(8.5, 7))
for j, route in enumerate(["near", "far"]):
    mp = d["maps"][route]; Hh = mp["H"]
    cnt = np.array(mp["counts"]).reshape(Hh, 7); price = np.array(mp["price_max"]).reshape(Hh, 7)
    klw = np.array(mp["kl_weighted"]).reshape(Hh, 7)
    wall = np.zeros((Hh, 7), bool); wall[1:Hh - 1, 3] = True
    pr = np.ma.array(price, mask=wall)
    im = ax[0, j].imshow(pr, cmap="viridis", vmin=0, vmax=10)
    for y in range(Hh):
        for x in range(7):
            if not wall[y, x]:
                ax[0, j].text(x, y, f"{int(cnt[y, x])}", ha="center", va="center", fontsize=6,
                              color="w" if price[y, x] < 6 else "k")
    ax[0, j].set_title(f"{route}: max KL price of any one-step deviation (nats)\nnumbers = human visits", loc="left")
    plt.colorbar(im, ax=ax[0, j], fraction=.046)
    im = ax[1, j].imshow(np.ma.array(klw, mask=wall), cmap="magma_r", vmin=0, vmax=max(1e-9, klw.max()))
    ax[1, j].set_title(f"{route}: KL actually spent at the optimum\n(β at theory takeover; door use {mp['p_star']:.2f})", loc="left")
    plt.colorbar(im, ax=ax[1, j], fraction=.046)
    for a in ax[:, j]:
        a.set_xticks([]); a.set_yticks([])
        a.add_patch(plt.Rectangle((2.5, -.5), 1, 1, fill=False, ec="r", lw=1.5))
fig.tight_layout(); fig.savefig("figures/fig5_gridworld_kl_maps.png", dpi=200, bbox_inches="tight")
print("ok")
