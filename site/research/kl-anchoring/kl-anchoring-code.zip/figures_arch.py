import json
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

R = json.load(open("results_arch_eps01.json")) + json.load(open("results_arch_eps0.json"))
ARCHS = ["tabular", "linear", "mlp16", "mlp64", "mlp256", "mlp1024", "cnn", "transformer"]
LAB = ["tabular", "linear", "MLP-16", "MLP-64", "MLP-256", "MLP-1024", "CNN", "transformer"]
MC = {"k1rew": "#4C72B0", "grpo": "#C44E52", "none": "#8C8C8C", "k1rew_all": "#55A868"}
ML = {"k1rew": "k1 in reward", "grpo": "GRPO (norm. adv. + k3 loss)", "none": "no KL", "k1rew_all": "k1 + anchor on held-out"}
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})


def runs(eps, arch, method):
    return [r for r in R if r["eps"] == eps and r["arch"] == arch and r["method"] == method]


def final(eps, arch, method, key):
    v = [np.mean(r["log"][-1][key]) for r in runs(eps, arch, method)]
    return np.mean(v), np.std(v)


def summary():
    S = {}
    for eps in (0.01, 0.0):
        for a in ARCHS:
            r0 = runs(eps, a, "k1rew")
            S[(eps, a, "ref")] = {k: float(np.mean([np.mean(r[f"ref_{k}"]) for r in r0])) for k in "TBO"}
            S[(eps, a, "exact")] = {k: float(np.mean([np.mean(r[f"exact_{k}"]) for r in r0])) for k in "TBO"}
            for m in MC:
                S[(eps, a, m)] = {k: float(final(eps, a, m, k)[0]) for k in "TBO"}
    return S


S = summary()
x = np.arange(len(ARCHS))

# Fig 6: in-distribution door use vs exact optimum; spillover to held-out and longer layouts
fig, ax = plt.subplots(1, 3, figsize=(14, 3.8), sharey=True)
for j, (k, title) in enumerate([("T", "a  RL-trained layouts"), ("B", "b  held-out layouts (in human data, no RL)"),
                                ("O", "c  longer layouts (H = 7, in neither)")]):
    w = 0.18
    for i, m in enumerate(["k1rew", "k1rew_all", "grpo", "none"]):
        mu = [final(0.01, a, m, k)[0] for a in ARCHS]; sd = [final(0.01, a, m, k)[1] for a in ARCHS]
        ax[j].bar(x + (i - 1.5) * w, mu, w, yerr=sd, color=MC[m], label=ML[m], error_kw=dict(lw=.6))
    ax[j].scatter(x, [S[(0.01, a, "ref")][k] for a in ARCHS], marker="_", s=250, color="k", zorder=5, label="reference (BC)")
    if k == "T":
        ax[j].scatter(x, [S[(0.01, a, "exact")][k] for a in ARCHS], marker="*", s=60, color="#DD8452", zorder=6,
                      label="exact KL optimum (tabular)")
    ax[j].set_xticks(x); ax[j].set_xticklabels(LAB, rotation=40, ha="right"); ax[j].set_title(title, loc="left")
ax[0].set_ylabel("door use after RL (mean of 3 seeds)"); ax[0].legend(frameon=False, fontsize=7, loc="upper left")
fig.suptitle("Humans used the door in 1% of demos; RL rewards speed on the RL-trained layouts only (β = 0.3)", x=0.01, ha="left")
fig.tight_layout(); fig.savefig("figures/fig6_arch_spillover.png", dpi=200, bbox_inches="tight")

# Fig 7: eps = 0 (humans never used it): reference floor by architecture and what RL does
fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
w = 0.27
for i, k in enumerate("TBO"):
    ax[0].bar(x + (i - 1) * w, [max(S[(0.0, a, "ref")][k], 1e-5) for a in ARCHS], w,
              color=["#4C72B0", "#55A868", "#C44E52"][i], label={"T": "RL layouts", "B": "held-out", "O": "longer (unseen)"}[k])
ax[0].set_yscale("log"); ax[0].set_xticks(x); ax[0].set_xticklabels(LAB, rotation=40, ha="right")
ax[0].set_ylabel("P_ref(door)"); ax[0].legend(frameon=False, fontsize=7)
ax[0].set_title("a  No human ever used the door: the reference's\n'never' is set by the architecture", loc="left")
w = 0.2
for i, m in enumerate(["k1rew", "k1rew_all", "grpo", "none"]):
    ax[1].bar(x + (i - 1.5) * w, [final(0.0, a, m, "O")[0] for a in ARCHS], w, color=MC[m], label=ML[m])
ax[1].scatter(x, [S[(0.0, a, "ref")]["O"] for a in ARCHS], marker="_", s=250, color="k", zorder=5, label="reference")
ax[1].set_xticks(x); ax[1].set_xticklabels(LAB, rotation=40, ha="right"); ax[1].set_ylabel("door use on longer layouts")
ax[1].set_title("b  Door use on longer layouts nobody saw. k1 holds them\nnear the reference; GRPO and no-KL drive it up (tabular = uniform)", loc="left"); ax[1].legend(frameon=False, fontsize=7)
fig.tight_layout(); fig.savefig("figures/fig7_arch_never.png", dpi=200, bbox_inches="tight")

# Fig 8: where drift happens first: TV(pi, pi_ref) by reference state density over training
show = ["mlp64", "mlp256", "cnn", "transformer"]
fig, ax = plt.subplots(2, len(show), figsize=(13, 5.6), sharex=True)
for row, m in enumerate(["k1rew", "none"]):
    for j, a in enumerate(show):
        rs = runs(0.01, a, m)
        its = [l["it"] for l in rs[0]["log"]]
        for key, c, lab in [("T_high", "#4C72B0", "RL layouts, frequent states (>0.3 visits/ep)"), ("T_low", "#8172B2", "RL layouts, uncommon (0.001-0.3)"),
("B_high", "#55A868", "held-out, frequent"),
                            ("O_high", "#C44E52", "longer layouts, frequent")]:
            ys = np.array([[l["tvbins"][key] if l["tvbins"][key] is not None else np.nan for l in r["log"]] for r in rs])
            ax[row, j].plot(np.array(its) + 1, np.nanmean(ys, 0), "o-", ms=2.5, color=c, label=lab)
        ax[row, j].set_xscale("log"); ax[row, j].set_title(f"{a}, {ML[m]}", loc="left", fontsize=8)
        if j == 0: ax[row, j].set_ylabel("mean TV(π, π_ref) per state")
for a_ in ax[1]: a_.set_xlabel("RL update + 1")
ax[0, 0].legend(frameon=False, fontsize=6.5)
fig.tight_layout(); fig.savefig("figures/fig8_arch_drift_by_density.png", dpi=200, bbox_inches="tight")

# text summary
for eps in (0.01, 0.0):
    print("eps", eps)
    for a in ARCHS:
        print(f"  {a:11s} ref T {S[(eps,a,'ref')]['T']:.4f} B {S[(eps,a,'ref')]['B']:.4f} O {S[(eps,a,'ref')]['O']:.4f} | exact T {S[(eps,a,'exact')]['T']:.3f} | " +
              " ".join(f"{m}: T {S[(eps,a,m)]['T']:.3f} B {S[(eps,a,m)]['B']:.3f} O {S[(eps,a,m)]['O']:.3f}" for m in MC))
