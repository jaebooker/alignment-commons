# Fresh-monitor calibration evidence

Eight calibration tasks only. Read REPORT.md first. No confirmation output or comparative catch-rate result. Public budget-scope.json states the already-reported phase/cap; private spending authorization and credentials are omitted. Raw generated text, request prompts, usage and nonce hashes are retained in api-cache for format/refusal auditing. Model-generated expressions were evaluated only by the bounded AST interpreter. The saved-record audit uses that frozen interpreter, not an independent semantic implementation. Prior protocol source freeze is retained for the disclosed pre-output schema repair.

Run `python audit_monitor_calibration.py` with NumPy/SciPy and the archive layout unchanged; no network calls are made by that audit.
