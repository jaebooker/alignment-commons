"""Read-only saved-record audit. Requires NumPy and pinned KataGo Python on PYTHONPATH."""
from pathlib import Path
import argparse,json,hashlib,re
import numpy as np
from katago.game.board import Board
from katago.game.gamestate import GameState
ap=argparse.ArgumentParser();ap.add_argument('directory',type=Path);ap.add_argument('--workspace',type=Path);a=ap.parse_args();p=a.directory;read=lambda f:json.loads(f.read_text());cases=read(p/'cases.json');summary=read(p/'summary.json');rows=read(p/'records.json');f=read(p/'freeze.json');checks={};hashcount=0
if a.workspace:
 for name,h in f['files'].items():assert hashlib.sha256((a.workspace/name).read_bytes()).hexdigest()==h,name;hashcount+=1
checks['frozen_files_verified']=hashcount
assert len(cases)==44 and len({c['id'] for c in cases})==44
errors=[];boardchecks=0;searchchecks=0;computed=[]
# Parse this deliberately flat, generated SGF independently; use official Board replay.
for case in cases:
 text=(p/'positions'/f"{case['id']}.sgf").read_text();nodes=text.strip().strip('()').split(';')[1:];root=nodes[0];prop=lambda k:re.search(r'(?<![A-Z])'+k+r'((?:\[[^]]*\])+)',root)
 coord=lambda s:(ord(s[1])-97,ord(s[0])-97)
 props={k:re.findall(r'\[([^]]*)\]',prop(k).group(1)) if prop(k) else [] for k in ['AB','AW','PL','KM','RU','SZ']}
 assert props['KM']==['6.5'] and props['RU']==['Japanese'] and props['SZ']==['19']
 g=case['game'];assert sorted(map(coord,props['AB']))==sorted(map(tuple,g['setup_black']));assert sorted(map(coord,props['AW']))==sorted(map(tuple,g['setup_white']))
 moves=[]
 for node in nodes[1:]:
  m=re.fullmatch(r'([BW])\[([a-s]{2}|)\]',node.strip());assert m,node;moves.append([1 if m[1]=='B' else 2,None if m[2]=='' else list(coord(m[2]))])
 assert moves==g['moves'] and len(moves)==9 and moves[-1]==[case['owner'],None]
 gs=GameState(19,GameState.RULES_JAPANESE)
 for color,key in [(1,'AB'),(2,'AW')]:
  for pt in props[key]:y,x=coord(pt);gs.board.set_stone(color,gs.board.loc(x,y))
 gs.board.set_pla(1 if props['PL']==['B'] else 2);gs.boards=[gs.board.copy()]
 for color,pt in moves:gs.play(color,Board.PASS_LOC if pt is None else gs.board.loc(pt[1],pt[0]))
 board=np.array([[gs.board.board[gs.board.loc(x,y)] for x in range(19)] for y in range(19)])
 # Independent mask through connected components (rather than the experiment flood-fill).
 from scipy.ndimage import label
 labels,count=label(board==case['owner']);idx=labels[tuple(case['ring_point'])];assert idx>0;mask=labels==idx;assert sorted(map(tuple,np.argwhere(mask)))==sorted(map(tuple,case['target_stones']))
 for net in ['b40','tf3']:
  raw=read(p/'raw'/f"{net}-{case['id']}.json");ref=next(x for x in read(p/'reference'/f'{net}.json') if x['id']==case['id']);assert np.array_equal(board,ref['board']);assert gs.board.pla==ref['current_player']==case['post_pass_player']
  native=np.zeros((19,19),int);seen=[]
  for line in raw['showboard'].splitlines():
   m=re.match(r'^\s*(\d{1,2})\s+(.+)$',line)
   if not m:continue
   chars=re.findall(r'[.XO+]',m[2]);assert len(chars)==19;native[19-int(m[1])]=[{'X':1,'O':2,'.':0,'+':0}[v] for v in chars];seen.append(int(m[1]))
  assert sorted(seen)==list(range(1,20)) and np.array_equal(board,native);assert ('Next player: White' if gs.board.pla==2 else 'Next player: Black') in raw['showboard'];boardchecks+=1
  lines=raw['raw_response'].split('whiteOwnership\n',1)[1].splitlines();arr=np.array([[float(x) for x in line.split()] for line in lines[:19]]);assert arr.shape==(19,19) and np.isfinite(arr).all();assert np.array_equal(arr,raw['white_ownership']);error=float(np.max(abs(arr-np.array(ref['white_ownership']))));errors.append(error);mean=float(arr[mask].mean())*(1 if case['owner']==2 else -1);r=next(x for x in rows if x['id']==case['id'] and x['model']==net);assert abs(mean-r['native_raw_owner_mean'])<1e-12 and abs(error-r['max_point_error'])<1e-12
  if case['search_sentinel'] or (net=='tf3' and case['search_tf3_flip']):
   s=read(p/'search'/f"{net}-{case['id']}.json")['native_response'];assert s['rootInfo']['visits']==16 and s['rootInfo']['currentPlayer']==('W' if gs.board.pla==2 else 'B');sv=float(np.array(s['ownership']).reshape(19,19)[mask].mean())*(1 if case['owner']==2 else -1);assert abs(sv-r['search_owner_mean'])<1e-12;searchchecks+=1
for net in ['b40','tf3']:
 queries=read(p/'search'/f'{net}-queries.json');expected={c['id'] for c in cases if c['search_sentinel'] or (net=='tf3' and c['search_tf3_flip'])};assert {q['id'] for q in queries}==expected
 for q in queries:
  c=next(c for c in cases if c['id']==q['id']);assert q['maxVisits']==16 and q['rules']=='japanese' and q['komi']==6.5;cols='ABCDEFGHJKLMNOPQRST';cv=lambda pt:'pass' if pt is None else cols[pt[1]]+str(19-pt[0]);assert q['moves']==[['B' if col==1 else 'W',cv(pt)] for col,pt in c['game']['moves']];assert q['initialStones']==[['B' if col==1 else 'W',cv(pt)] for col,key in [(1,'setup_black'),(2,'setup_white')] for pt in c['game'][key]]
rawgate=[];searchgate=[]
for n in ['b40','tf3']:
 for geom in [0,1]:
  for st in [0,1]:
   rs=[r for r in rows if r['model']==n and r['kind']=='fortified' and r['geometry']==geom and r['status']==st];assert len(rs)==6;positive=st==1 or (n=='b40' and geom==0);m=np.mean([r['native_raw_owner_mean'] for r in rs]);rawgate.append(m>.1 if positive else m<-.1)
   for r in rs:
    if r['search_owner_mean'] is not None:searchgate.append(r['search_owner_mean']>0 if positive else r['search_owner_mean']<0)
gates={'pipeline':max(errors)<=.005,'raw_pattern':bool(all(rawgate)),'search_pattern':bool(all(searchgate))};assert gates==summary['gates'];assert all(gates.values())==summary['joint_support'];assert len(searchgate)==16 and boardchecks==88 and searchchecks==19
result={'audit_passed':True,'meaning':'Saved-record integrity and recomputation passed; this does not pass the scientific pipeline gate or independently reproduce the study.','frozen_files_verified':hashcount,'sgfs_replayed_with_official_board':44,'native_and_reference_board_actor_checks':boardchecks,'independent_target_masks':44,'ownership_maps_reparsed':88,'search_queries_checked':searchchecks,'maps_failing_parity':sum(e>.005 for e in errors),'max_raw_point_error':max(errors),'recomputed_gates':gates,'joint_support':False}
(p/'integrity-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
