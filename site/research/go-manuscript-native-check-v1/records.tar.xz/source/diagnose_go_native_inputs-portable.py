from pathlib import Path
import os,sys,json,hashlib
import numpy as np
R=Path.cwd();L=R/'work/go-native-check-lab';P=R/'outputs/go-manuscript-native-check-v1';D=P/'diagnostic';D.mkdir(exist_ok=True)
sys.path.insert(0,str(L/'source'));sys.path.insert(0,str(L/'source/katago-python'))
from gtp_client import Client,ownership
from katago.game.board import Board
from katago.game.gamestate import GameState
from katago.game.features import Features
case=next(x for x in json.loads((P/'cases.json').read_text()) if x['id']=='flip-bal12');g=case['game'];gs=GameState(19,GameState.RULES_JAPANESE)
for col,key in [(1,'setup_black'),(2,'setup_white')]:
 for y,x in g[key]:gs.board.set_stone(col,gs.board.loc(x,y))
gs.board.set_pla(g['first_player']);gs.boards=[gs.board.copy()]
for col,p in g['moves']:gs.play(col,Board.PASS_LOC if p is None else gs.board.loc(p[1],p[0]))
a,b=gs.get_input_features(Features({'version':10},19));np.savez(D/'python-inputs.npz',spatial=a,global_input=b)
os.environ['GO_CONCEPT_DUMP_DIR']=str(D/'capture');os.environ['GO_CONCEPT_DUMP_LAYERS']='input,input_global'
bin=Path(os.environ['KATAGO_CAPTURE_BINARY'])
c=Client(bin,L/'models/b40-s11840935168.bin.gz',L/'gtp.cfg',D/'capture-stderr.log');c.query('loadsgf '+str(P/'positions/flip-bal12.sgf'));raw=c.query('kata-raw-nn 0 0.0');c.close()
outputs=[]
for d in sorted((D/'capture').iterdir()):
 m=json.loads((d/'manifest.json').read_text());t={x['name']:np.fromfile(d/x['file'],np.float32).reshape(x['shape']) for x in m['tensors']}
 n=t['input'].transpose(0,3,1,2);ng=t['input_global'];diff=np.abs(n-a)
 outputs.append({'directory':d.name,'spatial_max_error':float(diff.max()),'spatial_differing_planes':[{'plane':i,'points':int((diff[0,i]>1e-6).sum()),'max_error':float(diff[0,i].max())} for i in range(22) if diff[0,i].max()>1e-6], 'global_differences':[{'index':int(i),'native':float(ng[0,i]),'python':float(b[0,i])} for i in range(19) if abs(ng[0,i]-b[0,i])>1e-6]})
orig=json.loads((P/'raw/b40-flip-bal12.json').read_text());err=float(np.max(abs(ownership(raw)-np.array(orig['white_ownership']))))
result={'posthoc':True,'case':'flip-bal12','network':'b40','capture_binary_sha256':hashlib.sha256(bin.read_bytes()).hexdigest(),'capture_vs_original_raw_max_error':err,'evaluations':outputs,'interpretation':'Input capture diagnostic only; frozen primary pipeline result unchanged.'};(D/'input-diagnostic.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
