"""Post-hoc single-field diagnostic; never replaces frozen study outcomes."""
from pathlib import Path
import sys,os,json
import numpy as np,torch
R=Path.cwd();L=R/'work/go-native-check-lab';P=R/'outputs/go-manuscript-native-check-v1'
sys.path.insert(0,str(L/'source/paper'));os.environ['KATAGO_PY']=str(L/'source/katago-python');os.environ['GOCONCEPTS_NETS']=str(L/'models');torch.set_num_threads(1);torch.set_flush_denormal(True)
from goconcepts.mech_cross import Runner
from goconcepts.sgf import Game
from goconcepts.katago_adapter import gamestate_from_game
cases=json.loads((P/'cases.json').read_text());results=[]
for net,cid in [('b40','flip-bal12'),('tf3','flip-bal11')]:
 runner=Runner(net);c=next(c for c in cases if c['id']==cid);gs=gamestate_from_game(Game(**c['game']));enc=runner.model.encode(gs);before=float(enc[1][14]);enc[1][14]=1.;arr=runner.model.activations([enc],layers=[])['ownership'][0];white=arr if gs.board.pla==2 else -arr;native=np.array(json.loads((P/'raw'/f'{net}-{cid}.json').read_text())['white_ownership']);original=next(x for x in json.loads((P/'reference'/f'{net}.json').read_text()) if x['id']==cid)
 results.append({'model':net,'case':cid,'original_global14':before,'diagnostic_global14':1.,'original_max_point_error':float(np.max(abs(native-np.array(original['white_ownership'])))),'diagnostic_max_point_error':float(np.max(abs(native-white)))})
 np.save(P/'diagnostic'/f'{net}-{cid}-flag1-white.npy',white)
out={'posthoc':True,'selection':'Largest b40 discrepancy and second-largest tf3 discrepancy, selected after outcomes. Diagnostic only.','only_changed_feature':'Global input14: passWouldEndPhase 0 to1. Weights, board, history and all other encoded features unchanged.','results':results,'primary_joint_verdict':'Unsupported; frozen gate failure retained.','scope':'Localizes two worst-map discrepancies; not a corrected full-cohort confirmation or native causal-intervention replication.'};(P/'diagnostic/flag-diagnostic.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
