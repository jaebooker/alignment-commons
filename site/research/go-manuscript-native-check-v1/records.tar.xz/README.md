# Saved-record audit bundle

Study: go-manuscript-native-check-v1. Primary joint verdict unsupported.
Read REPORT.md and protocol.json before interpreting the data.

This archive includes saved data and audit/diagnostic source, not model weights, runtime packages, the frozen execution runner or a standalone engine build. The original execution runner is identified by freeze.json and retained locally. The portable capture diagnostic differs only by reading its binary path from KATAGO_CAPTURE_BINARY; it is post-hoc and not a frozen execution script.

For the saved-record audit, use Python with NumPy and SciPy, plus the official KataGo Python tree at commit 3c144b3e797185caa98e2328ae69757f36d791ba on PYTHONPATH:

    PYTHONPATH=/path/to/KataGo/python python source/audit_go_native_check.py .

Without --workspace this verifies saved records but does not verify the 119 original workspace source/model hashes. integrity-audit.json records the original full local audit, which used --workspace. Running the public audit writes its own integrity-audit.json with frozen_files_verified=0. Preserve the archived original if comparison is desired.

Pinned upstream source: https://github.com/lightvector/KataGo/tree/3c144b3e797185caa98e2328ae69757f36d791ba/python
Manuscript source: https://github.com/jaebooker/go-concepts
Exact file hashes, model identities and native executable version are in freeze.json. No upstream vendor code is redistributed here.

Raw ownership is White perspective. records.json reports fixed target owner perspective. Missing search values mean prespecified raw-only cases, not exclusions.
